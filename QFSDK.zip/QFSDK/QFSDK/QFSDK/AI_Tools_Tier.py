# Import the necessary library.
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.utils.data as Data
from torch.autograd import Variable
from sklearn import svm
from sklearn.metrics import mean_squared_error, mean_absolute_error

"======================Create the class for the Origin Oscillator Activation Function============================"
# origin_Oscillator is used for data preprocessing as a noise generator
class Origin_Oscillator():
    """
    E_t = f(a1 * E_t - a2 * I_t + x_t - eu)
    I_t = f(b1 * E_t - b2 * I_t - ev )
    S_t = f(x_t)
    Lee_t = (u_t - v_t)* exp(-K * x_t^2) + s_T
    'f' function is tanh activation function or sigmiod activation function
    suggest use tanh activation function according to wong oscillator
    """
    def __init__(self, N, s, a1, a2, b1, b2, ee, ei, K):
        # load all important hyper-parameters of Origin Oscillator
        self.N = N # the input data run N times in the chaotic neural network
        self.s =s
        self.a1 = a1
        self.a2 = a2
        self.b1 = b1
        self.b2 = b2
        self.ee = ee
        self.ei = ei
        self.K = K

        # create the container for chaotic neural network structure
    def Origin_tanh_Oscillator(self, input):
        #self.input = minmaxscaler(input)
        self.input = normalization(input)
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        Lee = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N-1):
            E[t+1] = np.tanh(self.s * (self.a1 * E[t] - self.a2 * I[t] + self.input - self.ee))
            I[t+1] = np.tanh(self.s * (self.b1 * E[t] - self.b2 * I[t] - self.ei))
            S[t+1] = np.tanh(self.s * (self.input))
            Lee[t+1] = (E[t+1]-I[t+1]) * np.exp(-self.K * pow(self.input, 2)) + S[t+1]

        return Lee[-1]

    def Origin_sigmoid_Oscillator(self, input):
        self.input = normalization(input)
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        Lee = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N-1):
            E[t+1] = sigmoid(self.s * (self.a1 * E[t] - self.a2 * I[t] + self.input - self.ee))
            I[t+1] = sigmoid(self.s * (self.b1 * E[t] - self.b2 * I[t] - self.ei))
            S[t+1] = sigmoid(self.s * (self.input))
            Lee[t+1] = (E[t+1]-I[t+1]) * np.exp(-self.K * pow(self.input, 2)) + S[t+1]

        return Lee[-1]

# test origin oscillator is used for visualizing the oscillator follow
class test_Origin_Oscillator():
    """
    E_t = f(a1 * E_t - a2 * I_t + x_t - eu)
    I_t = f(b1 * E_t - b2 * I_t - ev )
    S_t = f(x_t)
    Lee_t = (u_t - v_t)* exp(-K * x_t^2) + s_T
    'f' function is tanh activation function or sigmiod activation function
    suggest use tanh activation function according to wong oscillator
    """
    def __init__(self, N, s, a1, a2, b1, b2, ee, ei, K):
        # load all important hyper-parameters of Origin Oscillator
        self.N = N
        self.s =s
        self.a1 = a1
        self.a2 = a2
        self.b1 = b1
        self.b2 = b2
        self.ee = ee
        self.ei = ei
        self.K = K

    # create the container for chaotic neural network structure
    def Origin_tanh_Oscillator(self, input):
        #self.input = minmaxscaler(input)
        self.input = input
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        Lee = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N-1):
            E[t+1] = np.tanh(self.s * (self.a1 * E[t] - self.a2 * I[t] + self.input - self.ee))
            I[t+1] = np.tanh(self.s * (self.b1 * E[t] - self.b2 * I[t] - self.ei))
            S[t+1] = np.tanh(self.s * (self.input))
            Lee[t+1] = (E[t+1]-I[t+1]) * np.exp(-self.K * pow(self.input, 2)) + S[t+1]

        return Lee[-1]

    def Origin_sigmoid_Oscillator(self, input):
        #self.input = minmaxscaler(input)
        self.input = input
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        Lee = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N-1):
            E[t+1] = sigmoid(self.s * (self.a1 * E[t] - self.a2 * I[t] + self.input - self.ee))
            I[t+1] = sigmoid(self.s * (self.b1 * E[t] - self.b2 * I[t] - self.ei))
            S[t+1] = sigmoid(self.s * (self.input))
            Lee[t+1] = (E[t+1]-I[t+1]) * np.exp(-self.K * pow(self.input, 2)) + S[t+1]

        return Lee[-1]

"=======================Create the class for the LORS Oscillator Activation Function========================="
class LORS_Oscillator():
    """
    E_t = f(a1 * LORS_t + a2 * E_t - a3 * I_t + a4 * x_t - b_e)
    I_t = f(b1 * LORS_t - b2 * E_t - b3 * I_t +b4 * x_t - b_i )
    S_t = f(x_t)
    LORS_t = (E_t - I_t)* exp(-K * x_t^2) + S_t
    'f' function is tanh activation function or sigmiod activation function
    suggest use tanh activation function according to wong oscillator
    """
    def __init__(self, N, a1, a2, a3, a4, b1, b2, b3, b4, K, b_e, b_i, s):
        # load all important hyper-parameters of Origin Oscillator
        self.N = N
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.b1 = b1
        self.b2 = b2
        self.b3 = b3
        self.b4 = b4
        self.K = K
        self.b_e = b_e
        self.b_i = b_i
        self.s = s

    # create the container for chaotic neural network structure
    def LORS_tanh_Oscillator(self, input):
        self.input = normalization(input)
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        LORS = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N - 1):
            E[t + 1] = np.tanh(self.s * (self.a1 * LORS[t] + self.a2 * E[t] - self.a3 * I[t] + self.a4 * self.input - self.b_e))
            I[t + 1] = np.tanh(self.s * (self.b1 * LORS[t] - self.b2 * E[t] - self.b3 * I[t] + self.b4 * self.input - self.b_i))
            S[t + 1] = np.tanh(self.s * (self.input))
            LORS[t + 1] = (E[t + 1] - I[t + 1]) * np.exp(-self.K * pow(self.input, 2)) + S[t + 1]

        return LORS[-1]

    def LORS_sigmoid_Oscillator(self, input):
        self.input = normalization(input)
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        LORS = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N - 1):
            E[t + 1] = sigmoid(self.s * (self.a1 * LORS[t] + self.a2 * E[t] - self.a3 * I[t] + self.a4 * self.input - self.b_e))
            I[t + 1] = sigmoid(self.s * (self.b1 * LORS[t] - self.b2 * E[t] - self.b3 * I[t] + self.b4 * self.input - self.b_i))
            S[t + 1] = sigmoid(self.s * (self.input))
            LORS[t + 1] = (E[t + 1] - I[t + 1]) * np.exp(-self.K * pow(self.input, 2)) + S[t + 1]

        return LORS[-1]

class test_LORS_Oscillator():
    """
    E_t = f(a1 * LORS_t + a2 * E_t - a3 * I_t + a4 * x_t - b_e)
    I_t = f(b1 * LORS_t - b2 * E_t - b3 * I_t +b4 * x_t - b_i )
    S_t = f(x_t)
    LORS_t = (E_t - I_t)* exp(-K * x_t^2) + S_t
    'f' function is tanh activation function or sigmiod activation function
    suggest use tanh activation function according to wong oscillator
    """
    def __init__(self, N, a1, a2, a3, a4, b1, b2, b3, b4, K, b_e, b_i,s):
        # load all important hyper-parameters of Origin Oscillator
        self.N = N
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.b1 = b1
        self.b2 = b2
        self.b3 = b3
        self.b4 = b4
        self.K = K
        self.b_e = b_e
        self.b_i = b_i
        self.s = s

        # create the container for chaotic neural network structure
    def LORS_tanh_Oscillator(self, input):
        self.input = input
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        LORS = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N-1):
            E[t+1] = np.tanh(self.s * (self.a1 * LORS[t] + self.a2 * E[t] - self.a3 * I[t] + self.a4 * self.input - self.b_e))
            I[t+1] = np.tanh(self.s * (self.b1 * LORS[t] - self.b2 * E[t] - self.b3 * I[t] + self.b4 * self.input - self.b_i))
            S[t+1] = np.tanh(self.s * (self.input))
            LORS[t+1] = (E[t+1]-I[t+1]) * np.exp(-self.K * pow(self.input, 2)) + S[t+1]

        return LORS[-1]

    def LORS_sigmoid_Oscillator(self, input):
        self.input = input
        E = np.zeros((self.N, input.shape[0], input.shape[1]))
        I = np.zeros((self.N, input.shape[0], input.shape[1]))
        S = np.zeros((self.N, input.shape[0], input.shape[1]))
        LORS = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N-1):
            E[t+1] = sigmoid(self.s * (self.a1 * LORS[t] + self.a2 * E[t] - self.a3 * I[t] + self.a4 * self.input - self.b_e))
            I[t+1] = sigmoid(self.s * (self.b1 * LORS[t] - self.b2 * E[t] - self.b3 * I[t] + self.b4 * self.input - self.b_i))
            S[t+1] = sigmoid(self.s * (self.input))
            LORS[t+1] = (E[t+1]-I[t+1]) * np.exp(-self.K * pow(self.input, 2)) + S[t+1]

        return LORS[-1]

"=======================Create the class for the Wong Oscillator Activation Function========================="
class Wong_Oscillator():
    """
    u_t+1 = f(a1 * u_t - a2 * v_t + a3 * z_t + a4 * x_t - b_u)
    v_t+1 = f(b3 * z_t - b1 * u_t - b2 * v_t + b4 * x_t - b_v )
    w_t+1 = f(x_t)
    z_t+1 = (v_t - u_t)* exp(-K * x_t^2) + w_t
    'f' function is tanh activation function or sigmiod activation function
    suggest use tanh activation function according to wong oscillator
    """
    def __init__(self, N, a1, a2, a3, a4, b1, b2, b3, b4, k, b_u, b_v):
        # load all important hyper-parameters of Origin Oscillator
        self.N = N
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.b1 = b1
        self.b2 = b2
        self.b3 = b3
        self.b4 = b4
        self.k = k
        self.b_u = b_u
        self.b_v = b_v


    # create the container for chaotic neural network structure
    def Wong_tanh_Oscillator(self, input):
        self.input = normalization(input)
        u = np.zeros((self.N, input.shape[0], input.shape[1]))
        v = np.zeros((self.N, input.shape[0], input.shape[1]))
        w = np.zeros((self.N, input.shape[0], input.shape[1]))
        z = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N - 1):
            u[t + 1] = np.tanh(self.a1 * u[t] - self.a2 * v[t] + self.a3 * z[t] + self.a4 * self.input - self.b_u)
            v[t + 1] = np.tanh(self.b3 * z[t] - self.b1 * u[t] - self.b2 * v[t] + self.b4 * self.input - self.b_v)
            w[t + 1] = np.tanh(self.input)
            z[t + 1] = (v[t] - u[t]) * np.exp(-self.k * pow(self.input, 2)) + w[t]

        return z[-1]

    def Wong_sigmoid_Oscillator(self, input):
        self.input = normalization(input)
        u = np.zeros((self.N, input.shape[0], input.shape[1]))
        v = np.zeros((self.N, input.shape[0], input.shape[1]))
        w = np.zeros((self.N, input.shape[0], input.shape[1]))
        z = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N - 1):
            u[t + 1] = sigmoid(self.a1 * u[t] - self.a2 * v[t] + self.a3 * z[t] + self.a4 * self.input - self.b_u)
            v[t + 1] = sigmoid(self.b3 * z[t] - self.b1 * u[t] - self.b2 * v[t] + self.b4 * self.input - self.b_v)
            w[t + 1] = sigmoid(self.input)
            z[t + 1] = (v[t] - u[t]) * np.exp(-self.k * pow(self.input, 2)) + w[t]

        return z[-1]


class test_Wong_Oscillator():
    """
    u_t+1 = f(a1 * u_t - a2 * v_t + a3 * z_t + a4 * x_t - b_u)
    v_t+1 = f(b3 * z_t - b1 * u_t - b2 * v_t + b4 * x_t - b_v )
    w_t+1 = f(x_t)
    z_t+1 = (v_t - u_t)* exp(-K * x_t^2) + w_t
    'f' function is tanh activation function or sigmiod activation function
    suggest use tanh activation function according to wong oscillator
    """
    def __init__(self, N, a1, a2, a3, a4, b1, b2, b3, b4, k, b_u, b_v):
        # load all important hyper-parameters of Origin Oscillator
        self.N = N
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.b1 = b1
        self.b2 = b2
        self.b3 = b3
        self.b4 = b4
        self.k = k
        self.b_u = b_u
        self.b_v = b_v


    # create the container for chaotic neural network structure
    def Wong_tanh_Oscillator(self, input):
        self.input = input
        u = np.zeros((self.N, input.shape[0], input.shape[1]))
        v = np.zeros((self.N, input.shape[0], input.shape[1]))
        w = np.zeros((self.N, input.shape[0], input.shape[1]))
        z = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N - 1):
            u[t + 1] = np.tanh(self.a1 * u[t] - self.a2 * v[t] + self.a3 * z[t] + self.a4 * self.input - self.b_u)
            v[t + 1] = np.tanh(self.b3 * z[t] - self.b1 * u[t] - self.b2 * v[t] + self.b4 * self.input - self.b_v)
            w[t + 1] = np.tanh (self.input)
            z[t + 1] = (v[t+1] - u[t+1]) * np.exp(-self.k * pow(self.input, 2)) + w[t+1]

        return z[-1]

    def Wong_sigmoid_Oscillator(self, input):
        self.input = input
        u = np.zeros((self.N, input.shape[0], input.shape[1]))
        v = np.zeros((self.N, input.shape[0], input.shape[1]))
        w = np.zeros((self.N, input.shape[0], input.shape[1]))
        z = np.zeros((self.N, input.shape[0], input.shape[1]))

        for t in range(0, self.N - 1):
            u[t + 1] = sigmoid(self.a1 * u[t] - self.a2 * v[t] + self.a3 * z[t] + self.a4 * self.input - self.b_u)
            v[t + 1] = sigmoid(self.b3 * z[t] - self.b1 * u[t] - self.b2 * v[t] + self.b4 * self.input - self.b_v)
            w[t + 1] = sigmoid(self.input)
            z[t + 1] = (v[t+1] - u[t+1]) * np.exp(-self.k * pow(self.input, 2)) + w[t+1]

        return z[-1]

"=================================Create BP Nural Network Tools ==============================================="
"------------------------------------------- MLP Tool ---------------------------------------------------------"
class MLP(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(MLP, self).__init__()

        # Obtain the hyper-parameters
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        # Create the weight parameter of the input layer
        self.Wi = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        # Create the bias parameter of the input layer.
        self.Bi = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))
        # Create the weight parameter of the output layer
        self.Wo = nn.Parameter(torch.randn(self.hidden_size, self.output_size, requires_grad=True) * 0.01)
        # Create the bias parameter of the output layer.
        self.Bo = nn.Parameter(torch.zeros(self.output_size, requires_grad=True))

    def forward(self, x):
        # reshape the input data as following shape
        x = x.reshape((-1, self.input_size))
        i_t = torch.tanh(x @ self.Wi + self.Bi)
        o_t = i_t @ self.Wo + self.Bo
        return o_t
"------------------------------------------- RNN Tool ---------------------------------------------------------"
class RNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        # Create the super constructor.
        super(RNN, self).__init__()

        # Get the member variables.
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        # Create the weight parameter of the input layer.
        self.Wi = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        # Create the weight parameter of the hidden.
        self.Wh = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        # Create the bias parameter of the hidden layer.
        self.Bh = nn.Parameter(torch.zeros(self.hidden_size,requires_grad=True))
        # Create the weight parameter of the output layer.
        self.Wo = nn.Parameter(torch.randn(self.hidden_size, self.output_size, requires_grad=True) * 0.01)
        # Create the parameter of the bias_output.
        self.Bo = nn.Parameter(torch.zeros(self.output_size,requires_grad=True))


    def forward(self, x):
        x = x.reshape((-1, self.input_size))

        # h_t
        h_t = Variable(torch.zeros(x.shape[0], self.hidden_size))

        h_t = torch.tanh(x @ self.Wi + h_t @ self.Wh + self.Bh)
        o_t = h_t @ self.Wo + self.Bo

        return o_t
"------------------------------------------- GRU Tool ---------------------------------------------------------"
class GRU(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(GRU, self).__init__()

        # Get the member variables.
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        # zt
        self.Wz = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uz = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bz = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # r_t
        self.Wr = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Ur = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.br = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # h_t
        self.Wh = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uh = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bh = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # o_t
        self.Uo = nn.Parameter(torch.randn(self.hidden_size, self.output_size, requires_grad=True) * 0.01)
        self.bo = nn.Parameter(torch.zeros(self.output_size, requires_grad=True))

    def forward(self, x):
        x = x.reshape(((-1, self.input_size)))
        h_t, g_t, o_t = (
        Variable(torch.zeros(x.shape[0], self.hidden_size)),
        Variable(torch.zeros(x.shape[0], self.hidden_size)),
        Variable(torch.zeros(x.shape[0], self.output_size))
                        )

        z_t = torch.sigmoid(x @ self.Wz + h_t @ self.Uz + self.bz)
        r_t = torch.sigmoid(x @ self.Wr + h_t @ self.Ur + self.br)
        g_t = torch.tanh(x @ self.Wh + (r_t * h_t) @ self.Uh + self.bh)
        h_t = z_t * h_t + (1 - z_t) * g_t
        o_t = h_t @ self.Uo + self.bo

        return o_t
"------------------------------------------- LSTM Tool ---------------------------------------------------------"
class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTM, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        # i_t
        self.Wi = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Ui = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bi = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # f_t
        self.Wf = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uf = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bf = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # c_t
        self.Wc = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uc = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bc = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # o_t
        self.Wo = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uo = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bo = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # q_t
        self.Uq = nn.Parameter(torch.randn(self.hidden_size, self.output_size, requires_grad=True) * 0.01)
        self.bq = nn.Parameter(torch.zeros(self.output_size, requires_grad=True))


    def forward(self, x):
        x = x.reshape((-1, self.input_size))
        c_t, h_t, q_t = (
            Variable(torch.zeros(x.shape[0], self.hidden_size)),
            Variable(torch.zeros(x.shape[0], self.hidden_size)),
            Variable(torch.zeros(x.shape[0], self.output_size))
        )

        i_t = torch.sigmoid(x @ self.Wi + h_t @ self.Ui + self.bi)
        f_t = torch.sigmoid(x @ self.Wf + h_t @ self.Uf + self.bf)
        o_t = torch.sigmoid(x @ self.Wo + h_t @ self.Uo + self.bo)
        g_t = torch.tanh(x @ self.Wc + h_t @ self.Uc + self.bc)
        c_t = f_t * c_t + i_t * g_t
        h_t = o_t * torch.tanh(c_t)
        q_t = h_t @ self.Uq + self.bq

        return q_t

"=================================Test Multilayer Nural Network Tool ==============================================="

"--------------------------------------Multilayer MLP_Cell Tool ----------------------------------------------------"
class MLP_Cell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(MLP_Cell, self).__init__()

        # Obtain the hyper-parameters
        self.input_size = input_size
        self.hidden_size = hidden_size

        # Create the weight parameter of the input layer
        self.Wi = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        # Create the bias parameter of the input layer.
        self.Bi = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

    def forward(self, x):
        # reshape the input data as following shape
        x = x.reshape((-1, self.input_size))
        i_t = x @ self.Wi + self.Bi
        return i_t

"--------------------------------------Multilayer RNN_Cell Tool ---------------------------------------------------------"
class RNN_Cell(nn.Module):
    def __init__(self, input_size, hidden_size):
        # Create the super constructor.
        super(RNN_Cell, self).__init__()

        # Get the member variables.
        self.input_size = input_size
        self.hidden_size = hidden_size

        # Create the weight parameter of the input layer.
        self.Wi = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        # Create the weight parameter of the hidden.
        self.Wh = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        # Create the bias parameter of the hidden layer.
        self.Bh = nn.Parameter(torch.zeros(self.hidden_size,requires_grad=True))



    def forward(self, x):
        x = x.reshape((-1, self.input_size))
        h_t = Variable(torch.zeros(x.shape[0], self.hidden_size))

        h_t = x @ self.Wi + h_t @ self.Wh + self.Bh

        return h_t


"--------------------------------------Multilayer GRU_Cell Tool ---------------------------------------------------------"
class GRU_Cell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(GRU_Cell, self).__init__()

        # Get the member variables.
        self.input_size = input_size
        self.hidden_size = hidden_size

        # zt
        self.Wz = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uz = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bz = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # r_t
        self.Wr = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Ur = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.br = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # h_t
        self.Wh = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uh = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bh = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))


    def forward(self, x):
        x = x.reshape(((-1, self.input_size)))
        g_t, h_t = (
        Variable(torch.zeros(x.shape[0], self.hidden_size)),
        Variable(torch.zeros(x.shape[0], self.hidden_size)),
                        )

        z_t = torch.sigmoid(x @ self.Wz + h_t @ self.Uz + self.bz)
        r_t = torch.sigmoid(x @ self.Wr + h_t @ self.Ur + self.br)
        g_t = torch.tanh(x @ self.Wh + (r_t * h_t) @ self.Uh + self.bh)
        h_t = z_t * h_t + (1 - z_t) * g_t

        return h_t

"--------------------------------------Multilayer LSTM_Cell Tool ----------------------------------------------------"
class LSTM_Cell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTM_Cell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size

        # i_t
        self.Wi = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Ui = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bi = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # f_t
        self.Wf = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uf = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bf = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # c_t
        self.Wc = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uc = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bc = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))

        # o_t
        self.Wo = nn.Parameter(torch.randn(self.input_size, self.hidden_size, requires_grad=True) * 0.01)
        self.Uo = nn.Parameter(torch.randn(self.hidden_size, self.hidden_size, requires_grad=True) * 0.01)
        self.bo = nn.Parameter(torch.zeros(self.hidden_size, requires_grad=True))



    def forward(self, x):
        x = x.reshape((-1, self.input_size))
        c_t, h_t = (
            Variable(torch.zeros(x.shape[0], self.hidden_size)),
            Variable(torch.zeros(x.shape[0], self.hidden_size)),
        )

        i_t = torch.sigmoid(x @ self.Wi + h_t @ self.Ui + self.bi)
        f_t = torch.sigmoid(x @ self.Wf + h_t @ self.Uf + self.bf)
        o_t = torch.sigmoid(x @ self.Wo + h_t @ self.Uo + self.bo)
        g_t = torch.tanh(x @ self.Wc + h_t @ self.Uc + self.bc)
        c_t = f_t * c_t + i_t * g_t
        h_t = o_t * torch.tanh(c_t)

        return h_t
"====================================Enssential Normalization Tools and Activation Functions============================"

def minmaxscaler(x): #[0,1]
    x = np.array(x)
    x_scalered = (x-np.min(x))/(np.max(x)-np.min(x))
    return x_scalered

def sigmoid(x):
    x = np.array(x)
    result = 1/(1+np.exp(-x))
    return result

def normalization(x): #[-1,1]
    x = x-np.mean(x)
    x = x/np.max(np.abs(x))
    return x

def standardization(x):
    mu = np.mean(x, axis=0)
    sigma = np.std(x, axis=0)
    return (x - mu) / sigma

def relu(x):
    return np.maximum(0, x)

def tanh(x):
    x = np.array(x)
    result = (np.exp(x)-np.exp(-x))/(np.exp(x)+np.exp(-x))
    return result

"============================================Train Method=============================================================="
"-----------------------------------test for Origin Oscillated Data---------------------------------------"
def Origin_Oscillator_Test():
    # Origin_Oscillator test:
    security = pd.read_csv(r'..\399001.SZ.csv')
    History_Price = security.iloc[:, 2:6]
    Close_Price = normalization(History_Price.iloc[:, 2])

    "Origin Oscillator structure is  N,s, a1, a2, b1, b2, eu, ev, K"
    # Oscillator_data = Origin_Oscillator(10, 5, 5, 5, 1, 1, 0, 0, 500).Origin_tanh_Oscillator(test_data)
    Oscillator_Price = Origin_Oscillator(600, 5, 5, 5, 1, 1, 0, 0, 500).Origin_tanh_Oscillator(History_Price)
    Oscillator_Close_Price = Oscillator_Price[:, 0]
    mse = mean_squared_error(Close_Price, Oscillator_Close_Price)
    mae = mean_absolute_error(Close_Price, Oscillator_Close_Price)
    print('the mse of real_data oscillated_data is: %.6f\n the mae of real_data oscillated_data is: %.6f' % (mse, mae))

    plt.figure('Origin_Oscillagtor_test')
    plt.plot(Close_Price, 'r', Oscillator_Price, 'b')
    plt.legend(["Test_Data", 'Oscillator_Data'])
    plt.grid(True)
    plt.axis("tight")
    plt.xlabel("Timeseries")
    plt.ylabel("Oscillator_data")
    plt.title("Oscillator_Data")
    plt.show()

"----------------------------------------test for LORS Oscillated Data-------------------------------------------------"
def LORS_Oscillator_Test():
    # Origin_Oscillator test:
    security = pd.read_csv(r'..\399001.SZ.csv')
    History_Price = security.iloc[:, 2:6]
    Close_Price = normalization(History_Price.iloc[:, 2])
    "LORS Oscillator structure is N, a1, a2, a3, a4, b1, b2, b3, b4, K, b_e, b_i "
    LORS_Oscillator_Price = LORS_Oscillator(500, 0, 5, 5, 1, 0, -1, 1, 0, 1, 500, 0).LORS_sigmoid_Oscillator(History_Price)
    LORS_Oscillator_Close_Price = LORS_Oscillator_Price[:, 0]

    mse = mean_squared_error(Close_Price, LORS_Oscillator_Close_Price)
    mae = mean_absolute_error(Close_Price, LORS_Oscillator_Close_Price)
    print('the mse of real_data oscillated_data is: %.6f\n the mae of real_data oscillated_data is: %.6f' % (mse, mae))

    print(LORS_Oscillator_Close_Price)
    plt.figure('399001.SZ_close_price')
    plt.plot(Close_Price, 'r', LORS_Oscillator_Close_Price, 'b')
    plt.legend(["Real_Data", 'Oscillated_Data'])
    plt.grid(True)
    plt.axis("tight")
    plt.xlabel("Timeseries")
    plt.ylabel("Oscillator_Close")
    plt.title("Oscillator_Daily-Close")
    plt.show()

"--------------------------------------Visualization for test Oscillated Data-------------------------------------------"
def Wong_Oscillator_test():
    test_data = []
    sim = 0
    for i in np.arange(-1, 1, 0.002):
        sim = i + 0.02 * np.sin(sim)
        test_data.append(sim)

    test_data = np.array(test_data, dtype=np.float32)
    test_data = np.reshape(test_data,[-1, 1])

    Oscillated_data = test_Wong_Oscillator(600, 1, 1, 1, 1, -1, -1, -1, -1, 50, 0, 0).Wong_tanh_Oscillator(test_data)
    #Oscillated_data = test_Origin_Oscillator(600, 30, 5, 5, 1, 1, 0, 0, 500).Origin_sigmoid_Oscillator(test_data)
    plt.figure('test')
    plt.plot(test_data, 'r', Oscillated_data, 'b')
    plt.legend(["Real_Data",'Oscillated_Data'])
    plt.grid(True)
    plt.axis("tight")
    plt.xlabel("Timeseries")
    plt.ylabel("Oscillated_data")
    plt.title("Oscillated_data_test")
    plt.show()


"-------------------------test for deep learning tools and Oscillator layer-----------------------------------------"
def deep_learning_test():
    #Origin_Oscillator test:
    security = pd.read_csv(r'..\399001.SZ.csv')
    History_Price = security.iloc[:, 2:6]
    nor_History_Price = normalization(History_Price)
    train_dataset = nor_History_Price[:int(nor_History_Price.shape[0]*0.7)]
    train_validation = train_dataset.iloc[:,0]
    test_dataset = nor_History_Price[int(nor_History_Price.shape[0]*0.7):]
    test_validation = test_dataset.iloc[:,0]
    train_dataset, train_validation, test_dataset, test_validation = torch.tensor(train_dataset.values,dtype=torch.float),\
                                                                     torch.tensor(train_validation.values,dtype=torch.float),\
                                                                     torch.tensor(test_dataset.values,dtype=torch.float),\
                                                                     torch.tensor(test_validation.values,dtype=torch.float)
    train_validation= torch.reshape(train_validation, ((-1, 1)))
    test_validation = torch.reshape(test_validation,((-1,1)))


    tar_batch_size = 256
    tar_dataset = Data.TensorDataset(train_dataset,train_validation)
    loader = Data.DataLoader(
        dataset = tar_dataset,
        batch_size = tar_batch_size,
        shuffle = False,
        num_workers = 0)


    model = GRU(4, 256, 1)
    epochs = 500
    lr = 1e-5
    loss_function = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr)

    list_x = []
    list_y = []
    Loss = []

    for epoch in range(epochs):

        for batch_train, batch_validation in loader:
            batch_train = Variable(batch_train)
            batch_validation = Variable(batch_validation)
            output = model(batch_train)
            loss = loss_function(output, batch_validation)
            running_loss = loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if (epoch+1) % 10 == 0:
            Loss.append(running_loss)
            list_x.append(epoch)
            list_y.append(loss.item())
            print('Epoch: {}, Loss:{:.5f}, learning rate:{}'.format(epoch + 1, loss.item(), 1e-5))

    plt.plot(list_x, list_y, marker='*', color='b')
    plt.show()
    print('Finish Training')


"--------------------------------------------test for SVM tools -------------------------------------------------------"
def SVM_test():
    # Origin_Oscillator test:
    security = pd.read_csv(r'..\399001.SZ.csv')
    History_Price = security.iloc[:, 2:6]
    nor_History_Price = normalization(History_Price)
    train_dataset = nor_History_Price[:int(nor_History_Price.shape[0] * 0.7)]
    train_validation = train_dataset.iloc[:, 0]
    test_dataset = nor_History_Price[int(nor_History_Price.shape[0] * 0.7):]
    test_validation = test_dataset.iloc[:, 0]

    svr_rbf = svm.SVR(kernel='rbf', C=100, gamma=0.1)
    svr_lin = svm.SVR(kernel='linear', C=100)
    svr_poly = svm.SVR(kernel='poly', C=100, degree=3)
    svr_sigmoid = svm.SVR(kernel='sigmoid', C=100, gamma=0.1)

    svr_rbf.fit(train_dataset, train_validation)
    svr_lin.fit(train_dataset, train_validation)
    svr_poly.fit(train_dataset, train_validation)
    svr_sigmoid.fit(train_dataset, train_validation)

    y_rbf = svr_rbf.predict(test_dataset)
    y_lin = svr_lin.predict(test_dataset)
    y_poly = svr_poly.predict(test_dataset)
    y_sigmoid = svr_sigmoid.predict(test_dataset)

    print('Gaussian kernel error:', mean_absolute_error(test_validation, y_rbf), mean_squared_error(test_validation, y_rbf))
    print('linear kernel errors:', mean_absolute_error(test_validation, y_lin), mean_squared_error(test_validation, y_lin))
    print('polynomial kernel errors:', mean_absolute_error(test_validation, y_poly), mean_squared_error(test_validation, y_poly))
    print('sigmoid kernel errors:', mean_absolute_error(test_validation, y_sigmoid),
          mean_squared_error(test_validation, y_sigmoid))



# the main function to test the QPL_Generator
if __name__ == '__main__':
    SVM_test()












