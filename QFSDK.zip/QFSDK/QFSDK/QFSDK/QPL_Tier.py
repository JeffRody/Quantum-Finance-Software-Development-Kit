# Import Libraries.
import pandas as pd
import numpy as np
import math

"===================================QPL_Tier========================================"
# define the QPL_Generator Tier class
class QPL_Generator():

    # define the QPL_Generator
    def __init__(self, History_Price, Open_Price, QPL_Level):
        self.History_Price = History_Price
        self.Open_Price = Open_Price
        self.QPL_Level = QPL_Level

        Target_QPL_Level = self.QPL_Level
        P_QPL = Cal_P_QPL(self.History_Price, self.Open_Price)
        N_QPL = Cal_N_QPL(self.History_Price, self.Open_Price)

        Target_P_QPL_Level = P_QPL[Target_QPL_Level]
        Target_N_QPL_Level = N_QPL[Target_QPL_Level]

        print('Current Open Price is: %d\n'
              'The Target Price Level is: %d\n'
              'The Predicted Quantum High Price Level is: %d\n'
              'The Predict Quantum Low Price Level is: %d'%(Open_Price, Target_QPL_Level, Target_P_QPL_Level,  Target_N_QPL_Level))


# define the QPL_Generator Tier class
class QFS_Generator():

    # define the QPL_Generator
    def __init__(self, History_Price):
        self.History_Price = History_Price

        QFEL= Cal_QFEL(self.History_Price)
        print('The Quantum Field Signals are:',QFEL)


#define K_Value Calculator
def Cal_K_Value():
    K_Value = []
    for eL in range(0, 21):
        K_Value.append(pow((1.1924 + (33.2383 * eL) + (56.2169 * eL * eL)) / (1 + (43.6106 * eL)), 1 / 3))
    return K_Value

#define Get_Price_Return function
def Get_Price_Return(History_Price):
    Price_Return = []
    Close_Price = History_Price
    #Close_Price = list(x.iloc[:,0])
    for i in range(0,len(Close_Price)-1):
        if Close_Price[i+1] > 0:
            Price_Return.append(Close_Price[i]/Close_Price[i+1])
        else:
            Price_Return.append(1)
    return Price_Return

# define mu,sigma,dr calculator
def Cal_Price_Return(History_Price):
    Price_Return = Get_Price_Return(History_Price)
    # calculate mu, sigma, dr
    mu = np.mean(Price_Return)
    sigma = np.std(Price_Return)
    dr = (3 * sigma)/50
    return mu, sigma,dr

# define Wave_function calculator
def wave_function_NQ(History_Price):
    auxR = 0
    Q = [0 for i in range(100)]
    NQ = [0 for i in range(100)]
    Price_Return = Get_Price_Return(History_Price)
    maxRno = len(Price_Return)
    tQno = 0
    mu, sigma, dr = Cal_Price_Return(History_Price)

    for i in Price_Return:
        bFound = False
        nQ = 0
        auxR = 1 - (dr * 50)  # Left Boundary
        while (bFound != True) and (nQ < 100):
            if i > auxR and i <= (auxR + dr):
                Q[nQ] += 1
                tQno += 1
                bFound = True
            else:
                nQ += 1
                auxR = auxR + dr
   # Normalize
    NQ = np.array(Q) / tQno
    return NQ

    # define wave funtion Q calculator
def wave_function_Q(History_Price):
    NQ = wave_function_NQ(History_Price)
    # Find MaxQ and index of MaxQ
    maxQ = NQ.max()
    maxQno = NQ.tolist().index(maxQ)
    # Cal Q0/Q+1/Q-1
    Q0 = NQ[maxQno]
    Q1 = NQ[maxQno + 1]
    Qn1 = NQ[maxQno - 1]
    return maxQ, maxQno, Q0, Q1, Qn1

#define Lamda calculator
def Cal_L_Value(History_Price):
    r = []
    NQ = wave_function_NQ(History_Price)
    mu, sigma, dr = Cal_Price_Return(History_Price)
    maxQ, maxQno, Q0, Q1, Qn1 = wave_function_Q(History_Price)

    for i in range(100):
        r.append(1 - 50 * dr + i * dr)

    r0 = r[maxQno] - (dr / 2)
    r1 = r0 + dr
    rn1 = r0 - dr
    Lup = (pow(rn1, 2) * NQ[maxQno - 1]) - (pow(r1, 2) * NQ[maxQno + 1])
    Ldw = (pow(rn1, 4) * NQ[maxQno - 1]) - (pow(r1, 4) * NQ[maxQno + 1])
    L = abs(Lup / Ldw)
    return L

def Cal_QFEL(History_Price):
    QFEL = [0 for i in range(21)]
    K_Value = Cal_K_Value()
    L = Cal_L_Value(History_Price)
    # Cardano Method
    for eL in range(0, 21):
        p = -1 * pow((2 * eL + 1), 2)
        q = -1 * L * pow((2 * eL + 1), 3) * pow(K_Value[eL], 3)
        # Apply Cardano's Method to find the real root of the depressed cubic equation
        u = pow((-0.5 * q + math.sqrt(((q * q / 4.0) + (p * p * p / 27.0)))), 1 / 3)
        v = pow((-0.5 * q - math.sqrt(((q * q / 4.0) + (p * p * p / 27.0)))), 1 / 3)
        QFEL[eL] = u + v

    return QFEL

# define Normalized QPR (normalized quantum price return) calculator
def Cal_NQPR(History_Price):
    mu, sigma, dr = Cal_Price_Return(History_Price)
    QFEL = [0 for i in range(21)]
    QPR = [0 for i in range(21)]
    NQPR = [0 for i in range(21)]
    K_Value = Cal_K_Value()
    L = Cal_L_Value(History_Price)
    # Cardano Method
    for eL in range(0, 21):
        p = -1 * pow((2 * eL + 1), 2)
        q = -1 * L * pow((2 * eL + 1), 3) * pow(K_Value[eL], 3)
        # Apply Cardano's Method to find the real root of the depressed cubic equation
        u = pow((-0.5 * q + math.sqrt(((q * q / 4.0) + (p * p * p / 27.0)))), 1 / 3)
        v = pow((-0.5 * q - math.sqrt(((q * q / 4.0) + (p * p * p / 27.0)))), 1 / 3)
        QFEL[eL] = u + v

    for eL in range(0, 21):
        QPR[eL] = QFEL[eL] / QFEL[0]
        NQPR[eL] = 1 + 0.21 * sigma * QPR[eL]
    return NQPR

# define positive QPL calculator
def Cal_P_QPL(History_Price, Open_Price):
    # obtain the open or close price of current day
    Current_Open_Price = Open_Price
    P_QPL = []
    NQPR = Cal_NQPR(History_Price)
    # Cal P_QPLr
    for i in NQPR:
        P_QPL.append(Current_Open_Price * i)
    return P_QPL

# define Negative QPL calculator
def Cal_N_QPL(History_Price, Open_Price):
    # obtain the open or close price of current day
    Current_Open_Price = Open_Price
    N_QPL = []
    NQPR = Cal_NQPR(History_Price)
    # Cal N_QPL
    for i in NQPR:
        N_QPL.append(Current_Open_Price / i)
    return N_QPL



# the main function to test the QPL_Generator
if __name__ == '__main__':
    # create QPL Generator
    security = pd.read_csv(r'..\399001.SZ.csv')
    History_Price = list(security.iloc[:, 2])
    print(len(History_Price))
    print(len(Get_Price_Return(History_Price)))
    print(Cal_Price_Return(History_Price))
    print(len(wave_function_NQ(History_Price)))
    print(wave_function_Q(History_Price))
    print(Cal_L_Value(History_Price))
    Open_Price = 14314.0861
    print(Cal_P_QPL(History_Price, Open_Price))
    print(Cal_N_QPL(History_Price, Open_Price))
    QPL_Level = 1
    QPL = QPL_Generator(History_Price,Open_Price, QPL_Level)
    QFS = QFS_Generator(History_Price)

















