import pandas as pd
import numpy as np
from QFSDK import QPL_Tier
from QFSDK import AI_Tools_Tier
from sklearn.metrics import mean_squared_error, mean_absolute_error
import matplotlib.pyplot as plt
import torch
import torch.utils.data as Data
from torch.autograd import Variable
from QFSDK import AI_Tools_Tier as AI
import torch.nn as nn



"==========================Test for QPL Tier============================"
security = pd.read_csv(r'..\000001.SH.csv')
History_Price = security.iloc[:, 2]
Open_Price = 3050.124
QPL_Level = 2
QPL = QPL_Tier.QPL_Generator(History_Price, Open_Price, QPL_Level)
QFS = QPL_Tier.QFS_Generator(History_Price)


"===========================Test for AI Tools Tier============================="
# Obtain all data
History_Price = security.iloc[:, 2:6]

"------------------------------Normalization Tools ----------------------------"
# normalize the data to [0,1]
Close_Price_minmaxscaler = AI_Tools_Tier.minmaxscaler(History_Price.iloc[:, 2])
# normalize the data to [-1,1]
Close_Price_normalization = AI_Tools_Tier.normalization(History_Price.iloc[:, 2])

plt.figure('000001.SH_close_price')
plt.plot(Close_Price_normalization, 'r')
plt.legend(["Real_Data"])
plt.grid(True)
plt.axis("tight")
plt.xlabel("Timeseries")
plt.ylabel("normalization_data")
plt.title("normalization_Data")
plt.show()

"-----------------Origin Oscillator Activation Function -----------------------"

"An origin oscillator structure is as follow(N, s a1, a2, b1, b2, eu, ev, K)"
Oscillator = AI_Tools_Tier.Origin_Oscillator(600,5, 5, 5, 1, 1, 0, 0, 500)
#oscillated the target price series
Oscillator_Price = Oscillator.Origin_tanh_Oscillator(History_Price)
# obtain the target close price
Oscillator_Close_Price = Oscillator_Price[:, 0]

mse = mean_squared_error(Close_Price_normalization, Oscillator_Close_Price)
mae = mean_absolute_error(Close_Price_normalization, Oscillator_Close_Price)

print('the mse of real_data oscillated_data is: %.6f\n the mae of real_data oscillated_data is: %.6f' % (mse, mae))
print(Oscillator_Close_Price)
plt.figure('000001.SH_close_price')
plt.plot(Close_Price_normalization, 'r', Oscillator_Close_Price, 'b')
plt.legend(["Real_Data", 'Oscillated_Data'])
plt.grid(True)
plt.axis("tight")
plt.xlabel("Timeseries")
plt.ylabel("Origin_Oscillator_Close")
plt.title("Origin_Oscillator_Daily-Close")
plt.show()

"-----------------LORS Oscillator Activation Function -----------------------"

"An LORS oscillator structure is as follow:  N, a1, a2, a3, a4, b1, b2, b3, b4, K, b_e, b_i, s "
LORS_Oscillator = AI_Tools_Tier.LORS_Oscillator(600, 0, 5, 5, 1, 0, -1, 1, 0, 1, 500, 0, 1)
LORS_Oscillator_Price = LORS_Oscillator.LORS_tanh_Oscillator(History_Price)
LORS_Oscillator_Close_Price = LORS_Oscillator_Price[:, 0]

mse = mean_squared_error(Close_Price_normalization, LORS_Oscillator_Close_Price)
mae = mean_absolute_error(Close_Price_normalization, LORS_Oscillator_Close_Price)

print('the mse of real_data oscillated_data is: %.6f\n the mae of real_data oscillated_data is: %.6f' % (mse, mae))

print(LORS_Oscillator_Close_Price)
plt.figure('000001.SH_close_price')
plt.plot(Close_Price_normalization, 'r', LORS_Oscillator_Close_Price, 'b')
plt.legend(["Real_Data", 'Oscillated_Data'])
plt.grid(True)
plt.axis("tight")
plt.xlabel("Timeseries")
plt.ylabel("LORS_Oscillator_Close")
plt.title("LORS_Oscillator_Daily-Close")
plt.show()


"-----------------Wong Oscillator Activation Function -----------------------"
"An Wong oscillator structure is as follow:  N, a1, a2, a3, a4, b1, b2, b3, b4, K, b_u, b_v "
Wong_Oscillator = AI_Tools_Tier.Wong_Oscillator(1000, 0.6, 0.6, -0.5, 0.5, -0.6, -0.6, -0.5, 0.5, 50, 0, 0)
Wong_Oscillator_Price = Wong_Oscillator.Wong_tanh_Oscillator(History_Price)
Wong_Oscillator_Close_Price = Wong_Oscillator_Price[:, 0]

mse = mean_squared_error(Close_Price_normalization, Wong_Oscillator_Close_Price)
mae = mean_absolute_error(Close_Price_normalization, Wong_Oscillator_Close_Price)

print('the mse of real_data oscillated_data is: %.6f\n the mae of real_data oscillated_data is: %.6f' % (mse, mae))

print(Wong_Oscillator_Close_Price)
plt.figure('399001.SZ_close_price')
plt.plot(Close_Price_normalization, 'r', Wong_Oscillator_Close_Price, 'b')
plt.legend(["Real_Data", 'Oscillated_Data'])
plt.grid(True)
plt.axis("tight")
plt.xlabel("Timeseries")
plt.ylabel("Wong_Oscillator_Close")
plt.title("Wong_Oscillator_Daily-Close")
plt.show()

"================================================test for AI Tool ======================================================================"

# Origin_Oscillator test:
security = pd.read_csv(r'..\000001.SH.csv')
History_Price = security.iloc[:, 2:6]
nor_History_Price = AI.normalization(History_Price)
train_dataset = nor_History_Price[:int(nor_History_Price.shape[0] * 0.7)]
train_validation = train_dataset.iloc[:, 0]
test_dataset = nor_History_Price[int(nor_History_Price.shape[0] * 0.7):]
test_validation = test_dataset.iloc[:, 0]
train_dataset, train_validation, test_dataset, test_validation = torch.tensor(train_dataset.values, dtype=torch.float), \
                                                                 torch.tensor(train_validation.values,
                                                                              dtype=torch.float), \
                                                                 torch.tensor(test_dataset.values, dtype=torch.float), \
                                                                 torch.tensor(test_validation.values, dtype=torch.float)
train_validation = torch.reshape(train_validation, ((-1, 1)))
test_validation = torch.reshape(test_validation, ((-1, 1)))

tar_batch_size = 256
tar_dataset = Data.TensorDataset(train_dataset, train_validation)
loader = Data.DataLoader(
    dataset=tar_dataset,
    batch_size=tar_batch_size,
    shuffle=False,
    num_workers=0)

#model = AI.LSTM(4, 256, 1)
model = nn.Sequential(AI.LSTM_Cell(4,256), nn.Tanh(),AI.GRU_Cell(256,256), AI.MLP_Cell(256,1))
epochs = 500
lr = 1e-5
loss_function = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr)

list_x = []
list_y = []
Loss = []

for epoch in range(epochs):
    for batch_train, batch_validation in loader:
        output = model(batch_train)
        loss = loss_function(output, batch_validation)
        running_loss = loss.item()
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    if (epoch + 1) % 10 == 0:
        Loss.append(running_loss)
        list_x.append(epoch)
        list_y.append(loss.item())
        print('Epoch: {}, Loss:{:.5f}, learning rate:{}'.format(epoch + 1, loss.item(), 1e-5))

plt.plot(list_x, list_y, marker='*', color='b')
plt.show()

print('Finish Training')


